# Setup Keycloak using Docker and PostgreSQL

Companion repository for the blog post : "Setup Keycloak with Docker and PostgreSQL"

Checkout the blog post for more details : https://gauthier-cassany.com/posts/setup-keycloak-docker
